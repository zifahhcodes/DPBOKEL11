import 'dart:convert';
import 'package:equatable/equatable.dart';

Teacher teachersFromMap(String str) => Teacher.fromMap(json.decode(str));

String teachersToMap(Teacher data) => json.encode(data.toMap());

Lecture lectureFromMap(String str) => Lecture.fromMap(json.decode(str));

String lectureToMap(Lecture data) => json.encode(data.toMap());


class Teacher extends Equatable {
  final int tcrId; // This will be auto-incremented by the database
  final String fullName;
  final String email;
  final String tcrName;
  final String password;

  Teacher({
    required this.fullName,
    required this.email,
    required this.tcrName,
    required this.password,
    this.tcrId = 0, // Default value for auto-incremented ID
  });

  factory Teacher.fromMap(Map<String, dynamic> map) {
    return Teacher(
      tcrId: map['tcrId'],
      fullName: map['fullName'],
      email: map['email'],
      tcrName: map['tcrName'],
      password: map['password'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'fullName': fullName,
      'email': email,
      'tcrName': tcrName,
      'password': password,
    };
  }

  @override
  List<Object?> get props => [tcrId, fullName, email, tcrName, password];
}


class Lecture {
  final int? lctId;
  final String lctName;
  final int tcrId;

  Lecture({
    this.lctId,
    required this.lctName,
    required this.tcrId,
  });

  // Factory constructor to create a Lecture object from a Map (e.g., a database row)
  factory Lecture.fromMap(Map<String, dynamic> json) => Lecture(
        lctId: json["lctId"],
        lctName: json["lctName"],
        tcrId: json["tcrId"],
      );

  // Method to convert a Lecture object into a Map (e.g., for inserting into the database)
  Map<String, dynamic> toMap() => {
        "lctId": lctId,
        "lctName": lctName,
        "tcrId": tcrId,
      };
}