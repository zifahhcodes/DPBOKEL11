import 'dart:io';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import '../JSON/teacture.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();

  factory DatabaseHelper() => _instance;

  DatabaseHelper._internal();

  static const String _databaseName = "auth.db";
  Database? _database;

  // Table creation queries
  static const String _teacherTableQuery = '''
    CREATE TABLE Teacher (
      tcrId INTEGER PRIMARY KEY AUTOINCREMENT,
      fullName TEXT,
      email TEXT,
      tcrName TEXT UNIQUE,
      password TEXT
    )
  ''';

  static const String _lectureTableQuery = '''
    CREATE TABLE Lecture (
      lctId INTEGER PRIMARY KEY AUTOINCREMENT,
      lctName TEXT,
      tcrId INTEGER,
      FOREIGN KEY(tcrId) REFERENCES Teacher(tcrId)
    )
  ''';

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB();
    return _database!;
  }

  Future<Database> _initDB() async {
    try {
      final databasePath = await getDatabasesPath();
      final path = join(databasePath, _databaseName);

      return openDatabase(
        path,
        version: 2,
        onCreate: (db, version) async {
          await db.execute(_teacherTableQuery);
          await db.execute(_lectureTableQuery);
        },
      );
    } catch (e, stack) {
      print('Database initialization error: $e');
      print(stack);
      rethrow; // Ensure errors don't get swallowed.
    }
  }


  // Teacher Authentication
  Future<bool> authenticate(Teacher teacher) async {
    final db = await database;
    try {
      final result = await db.rawQuery(
        "SELECT * FROM Teacher WHERE tcrName = ? AND password = ?",
        [teacher.tcrName, teacher.password],
      );
      return result.isNotEmpty;
    } catch (e) {
      print('Authentication error: $e');
      return false;
    }
  }

  // Create a new teacher
  Future<int> createTeacher(Teacher teacher) async {
    final db = await database;
    try {
      return await db.insert(
        "Teacher",
        teacher.toMap(),
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
    } catch (e) {
      print('Error creating teacher: $e');
      return -1;
    }
  }

  // Fetch specific teacher
  Future<Teacher?> getTeacher(String tcrName, String password) async {
    final db = await database;
    try {
      final result = await db.query(
        "Teacher",
        where: "tcrName = ? AND password = ?",
        whereArgs: [tcrName, password],
      );
      if (result.isNotEmpty) {
        return Teacher.fromMap(result.first);
      }
    } catch (e) {
      print('Error fetching teacher: $e');
    }
    return null;
  }

  // Fetch all teachers
  Future<List<Teacher>> fetchAllTeachers() async {
    final db = await database;
    try {
      final result = await db.query("Teacher");
      return result.map((e) => Teacher.fromMap(e)).toList();
    } catch (e) {
      print('Error fetching all teachers: $e');
      return [];
    }
  }

  // Delete all data from tables
  Future<void> clearAllTables() async {
    final db = await database;
    try {
      await db.delete('Teacher');
      await db.delete('Lecture');
      print('All tables cleared successfully.');
    } catch (e) {
      print('Error clearing tables: $e');
    }
  }

  // Close database connection
  Future<void> closeDB() async {
    final db = await database;
    try {
      await db.close();
      print('Database connection closed.');
    } catch (e) {
      print('Error closing database: $e');
    }
  }
}