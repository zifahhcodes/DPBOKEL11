import 'package:flutter/material.dart';
import 'package:edusync/database/database_helper.dart';
import 'package:edusync/JSON/teacture.dart';

class DatabaseViewer extends StatefulWidget {
  const DatabaseViewer({Key? key}) : super(key: key);

  @override
  State<DatabaseViewer> createState() => _DatabaseViewerState();
}

class _DatabaseViewerState extends State<DatabaseViewer> {
  late Future<List<Teacher>> teachersFuture;

  @override
  void initState() {
    super.initState();
    teachersFuture = _fetchTeachers();
  }

  Future<List<Teacher>> _fetchTeachers() async {
    final dbHelper = DatabaseHelper();
    try {
      final teachersData = await dbHelper.fetchAllTeachers();
      return teachersData; // fetchAllTeachers already returns a List<Teacher>
    } catch (e) {
      print('Error fetching teachers: $e');
      return [];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Database Viewer'),
      ),
      body: FutureBuilder<List<Teacher>>(
        future: teachersFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No data found.'));
          } else {
            final teachers = snapshot.data!;
            return ListView.builder(
              itemCount: teachers.length,
              itemBuilder: (context, index) {
                final teacher = teachers[index];
                return ListTile(
                  leading: CircleAvatar(
                    child: Text(
                      teacher.fullName.isNotEmpty
                          ? teacher.fullName[0].toUpperCase()
                          : '?',
                    ),
                  ),
                  title: Text(teacher.fullName),
                  subtitle: Text(teacher.email),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () async {
                      final dbHelper = DatabaseHelper();
                      await dbHelper.clearAllTables(); // Add teacher-specific deletion if needed
                      setState(() {
                        teachersFuture = _fetchTeachers(); // Refresh the data
                      });
                    },
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}